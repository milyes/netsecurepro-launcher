#!/bin/bash
# NetSecurePro Menu Launcher v1.0
SCRIPT_NAME="NetSecurePro Menu Launcher"
SCRIPT_VERSION="1.0"
LOG_FILE="/sdcard/netsecurepro.log"
PROJECTS_DIR="/sdcard/Projets"
DATE_FORMAT="%Y-%m-%d %H:%M:%S"

function log_action() {
  echo "[$(date +"$DATE_FORMAT")] $1" >> "$LOG_FILE"
}

function verify_identity() {
  if [[ -f "$HOME/.ia_password" ]]; then
    STORED_PASS=$(cat "$HOME/.ia_password")
  else
    STORED_PASS="unlock_ai"
  fi
  read -s -p "🔐 Entrez le mot de passe IA pour accéder au menu : " PASS
  echo
  if [[ "$PASS" != "$STORED_PASS" ]]; then
    echo "❌ Accès refusé."
    exit 1
  fi
}

function run_project() {
  if [[ -f "$PROJECTS_DIR/$1.sh" ]]; then
    bash "$PROJECTS_DIR/$1.sh"
  elif [[ -f "$PROJECTS_DIR/$1.bin" ]]; then
    "$PROJECTS_DIR/$1.bin"
  elif [[ -f "$PROJECTS_DIR/$1.html" ]]; then
    termux-open "$PROJECTS_DIR/$1.html"
  elif [[ -f "$PROJECTS_DIR/$1.apk" ]]; then
    termux-open "$PROJECTS_DIR/$1.apk"
  elif [[ -f "$PROJECTS_DIR/$1.zip" ]]; then
    unzip -q "$PROJECTS_DIR/$1.zip" -d "$PROJECTS_DIR/extracted"
    echo "✅ Projet extrait dans : $PROJECTS_DIR/extracted"
  else
    echo "❌ Projet non trouvé."
  fi
}

function main_menu() {
  clear
  echo "======================================"
  echo "  NetSecurePro Menu Launcher v1.0  "
  echo "======================================"
  echo "1. 📂 Projets"
  echo "2. 🛠️ Outils"
  echo "3. 📊 Statistiques"
  echo "4. 🔧 Paramètres"
  echo "5. 🚪 Quitter"
  echo "======================================"
  read -p "Choisissez une option : " OPTION
  case $OPTION in
    1) show_projects_menu ;;
    2) show_tools_menu ;;
    3) show_stats_menu ;;
    4) show_settings_menu ;;
    5) exit 0 ;;
    *) echo "❌ Option invalide." ; main_menu ;;
  esac
}

function show_projects_menu() {
  clear
  echo "======================================"
  echo "  Projets NetSecurePro  "
  echo "======================================"
  ls -1 "$PROJECTS_DIR"
  echo "======================================"
  read -p "Entrez le nom du projet à lancer : " PROJECT
  run_project "$PROJECT"
  main_menu
}

function show_tools_menu() {
  clear
  echo "======================================"
  echo "  Outils NetSecurePro  "
  echo "======================================"
  echo "1. 📊 Analyse de logs"
  echo "2. 🔒 Générateur de mots de passe"
  echo "3. 📈 Moniteur de ressources"
  echo "4. 🔙 Retour au menu principal"
  echo "======================================"
  read -p "Choisissez une option : " OPTION
  case $OPTION in
    1) show_logs_analysis ;;
    2) generate_password ;;
    3) show_resources_monitor ;;
    4) main_menu ;;
    *) echo "❌ Option invalide." ; show_tools_menu ;;
  esac
}

function show_logs_analysis() {
  clear
  echo "======================================"
  echo "  Analyse des logs NetSecurePro  "
  echo "======================================"
  cat "$LOG_FILE" | grep -i "erreur"
  read -p "Appuyez sur Entrée pour continuer..." 
  show_tools_menu
}

function generate_password() {
  clear
  echo "======================================"
  echo "  Générateur de mots de passe NetSecurePro  "
  echo "======================================"
  PASSWORD=$(tr -dc 'A-Za-z0-9!@#$%^&*()' < /dev/urandom | fold -w 12 | head -n 1)
  echo "Mot de passe généré : $PASSWORD"
  read -p "Appuyez sur Entrée pour continuer..." 
  show_tools_menu
}

function show_resources_monitor() {
  clear
  echo "======================================"
  echo "  Moniteur de ressources NetSecurePro  "
  echo "======================================"
  free -m
  read -p "Appuyez sur Entrée pour continuer..." 
  show_tools_menu
}

function show_stats_menu() {
  clear
  echo "======================================"
  echo "  Statistiques NetSecurePro  "
  echo "======================================"
  echo "1. 📊 Nombre de projets lancés"
  echo "2. ⏰ Temps d'exécution moyen"
  echo "3. 🔙 Retour au menu principal"
  echo "======================================"
  read -p "Choisissez une option : " OPTION
  case $OPTION in
    1) show_launched_projects ;;
    2) show_execution_time ;;
    3) main_menu ;;
    *) echo "❌ Option invalide." ; show_stats_menu ;;
  esac
}

function show_launched_projects() {
  clear
  grep -c "lancé" "$LOG_FILE"
  read -p "Appuyez sur Entrée pour continuer..." 
  show_stats_menu
}

function show_execution_time() {
  clear
  awk '{sum+=$2} END {print "Temps moyen d'exécution : " sum/NR " secondes"}' "$LOG_FILE"
  read -p "Appuyez sur Entrée pour continuer..." 
  show_stats_menu
}

function show_settings_menu() {
  clear
  echo "======================================"
  echo "  Paramètres NetSecurePro  "
  echo "======================================"
  echo "1. 🔄 Réinitialiser les logs"
  echo "2. 📝 Modifier le mot de passe IA"
  echo "3. 🔙 Retour au menu principal"
  echo "======================================"
  read -p "Choisissez une option : " OPTION
  case $OPTION in
    1) reset_logs ;;
    2) change_password ;;
    3) main_menu ;;
    *) echo "❌ Option invalide." ; show_settings_menu ;;
  esac
}

function reset_logs() {
  > "$LOG_FILE"
  echo "✅ Logs réinitialisés."
  sleep 1
  show_settings_menu
}

function change_password() {
  read -s -p "📝 Entrez le nouveau mot de passe IA : " NEW_PASS
  echo
  echo "$NEW_PASS" > "$HOME/.ia_password"
  echo "✅ Mot de passe IA mis à jour."
  sleep 1
  show_settings_menu
}

verify_identity
main_menu
